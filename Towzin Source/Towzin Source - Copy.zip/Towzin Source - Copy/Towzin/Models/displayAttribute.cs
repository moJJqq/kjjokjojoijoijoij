﻿using System;

namespace Towzin.Models
{
    internal class displayAttribute : Attribute
    {
    }
}